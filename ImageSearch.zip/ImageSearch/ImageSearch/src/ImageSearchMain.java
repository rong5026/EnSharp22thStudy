import Controller.SearchingImage;
import Model.HistoryDAO;

public class ImageSearchMain {

	public static void main(String[] args) {
		SearchingImage main = new SearchingImage();
		main.StartSearchImage();
		
	}



}
