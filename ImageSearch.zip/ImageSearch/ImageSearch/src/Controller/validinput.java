package Controller;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class validinput implements ActionListener {


	@Override
	public void actionPerformed(ActionEvent e) {
		
	}

	
	
}
