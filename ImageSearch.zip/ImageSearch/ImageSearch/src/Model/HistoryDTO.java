package Model;

public class HistoryDTO {

	private String word;
	
	
	
	 public String getWord()
     {
		 
		 return word;
       
     }
	 public void setWord(String word) {
		
		this.word = word;
		 
	 }
	 
	 
	 
	 
	
}
